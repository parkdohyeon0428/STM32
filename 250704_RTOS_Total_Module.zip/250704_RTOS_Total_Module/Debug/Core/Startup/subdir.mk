################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
../Core/Startup/startup_stm32f411retx.s 

OBJS += \
./Core/Startup/startup_stm32f411retx.o 

S_DEPS += \
./Core/Startup/startup_stm32f411retx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Startup/%.o: ../Core/Startup/%.s Core/Startup/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/Button" -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/LedBar" -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/LCD" -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/FND" -I"D:/STM32/250704_RTOS_Total_Module/Core/ap/Controller" -I"D:/STM32/250704_RTOS_Total_Module/Core/ap/Listener" -I"D:/STM32/250704_RTOS_Total_Module/Core/ap/Model" -I"D:/STM32/250704_RTOS_Total_Module/Core/ap/Presenter" -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/DHT11" -I"D:/STM32/250704_RTOS_Total_Module/Core/driver/UltraSonic" -I"D:/STM32/250704_RTOS_Total_Module/Core/Src" -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-Core-2f-Startup

clean-Core-2f-Startup:
	-$(RM) ./Core/Startup/startup_stm32f411retx.d ./Core/Startup/startup_stm32f411retx.o

.PHONY: clean-Core-2f-Startup

